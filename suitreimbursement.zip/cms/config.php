<?php
    $SERVER="localhost:1000";

    $imageheight = '50%';
    $imagewidth = '50%';
    $imageroot = 'images';
?>